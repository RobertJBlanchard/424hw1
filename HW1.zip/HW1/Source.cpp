//  I used Chat GPT to allign my code and make it easier to read for troubleshooting.
//  Chat GPT also helped me with debugging.

#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////// Functions:
// Question 4 Function to compute the dot product between two vectors
double dot_product(const vector<double>& w, const vector<double>& x) {
    double result = 0.0;
    for (size_t i = 0; i < w.size(); ++i) {
        result += w[i] * x[i];
    }
    return result;
}

// Question 5 Function to compute the sigmoid function
double sigmoid(double zz) {
    return 1.0 / (1.0 + exp(-zz));
}

// Question 5 Function to compute the gradient of the sigmoid function
double gradient_sigmoid(double zz) {
    double sig_z = sigmoid(zz);
    return sig_z * (1 - sig_z);
}

// Question 6 Function to compute the gradient of the cost function
double gradient_cost(double y_predicted, double y_) {
    return 2.0 * (y_predicted - y_);
}

// Question 7 Function to compute the gradient of weights
vector<double> gradient_weights(const vector<double>& w, const vector<double>& x, double y) {
    vector<double> dw(w.size(), 0.0);
    double z = dot_product(w, x);
    double sig_z = sigmoid(z);
    double grad_sig_z = gradient_sigmoid(z);

    for (size_t i = 0; i < w.size(); ++i) {
        dw[i] = 2.0 * (sig_z - y) * sig_z * (1 - sig_z) * x[i];
    }

    return dw;
}

// Question 7 Function to update weights
void update_weights(vector<double>& w, const vector<double>& dw, double alpha) {
    for (size_t i = 0; i < w.size(); ++i) {
        w[i] -= alpha * dw[i];
    }
}

// Question 8 Function to train the aircraft classifier
void train_classifier(vector<vector<double>>& aircraft_data, vector<double>& w, double alpha, int max_iterations) {
    for (int iteration = 0; iteration < max_iterations; ++iteration) {
        for (const auto& data_row : aircraft_data) {
            // Extract the features and engine type from the data row
            vector<double> x(data_row.begin(), data_row.end() - 1); // Features
            double y = data_row.back(); // Engine Type

            // Compute gradient weights
            vector<double> dw = gradient_weights(w, x, y);

            // Update weights
            update_weights(w, dw, alpha);
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main() {

    // Question 1
    cout << endl << "Question 1" << endl;

    // Constants and initial conditions
    const double Lp = 0.5;        // Roll damping coefficient
    const double Ldelta = 0.7;    // Aileron effectiveness
    const double p0 = 1.0;        // Initial roll rate in rad/s
    const double delta_a = 1.0;   // Aileron deflection angle
    const double delta_t = 0.01;  // Time step size in seconds
    const double total_time = 5.0; // Total simulation time in seconds
    double p = p0;                 // Initial roll rate

    // Simulation loop
    for (double t = 0.0; t <= total_time; t += delta_t) {
        // Calculates the roll rate at the current time step
        double pdot = Lp * p + Ldelta * delta_a;

        // Prints the result at the current time step
        cout << "Time: " << t << " seconds, Roll Rate: " << p << " rad/s" << endl;

        // Updates the roll rate for the next time step
        p += pdot * delta_t;
    }


    // Question 2
    cout << endl << "Question 2" << endl;

    const double K = -2.0; // Feedback control gain

    // Simulation loop
    for (double t = 0.0; t <= total_time; t += delta_t) {
        // Calculates the aileron deflection using feedback control law
        double delta_a = K * p;

        // Calculates the roll rate at the current time step
        double pdot = Lp * p + Ldelta * delta_a;

        // Prints the result at the current time step
        cout << "Time: " << t << " seconds, Roll Rate: " << p << " rad/s" << endl;

        // Updates the roll rate for the next time step
        p += pdot * delta_t;
    }


    // Question 3
    cout << endl << "Question 3" << endl;

    double Ko = 0.5;           // Initial feedback control gain
    const double alpha = 0.1; // Adaptive rate

    // Simulation loop
    for (double t = 0.0; t <= total_time; t += delta_t) {
        // Calculate the aileron deflection using adaptive feedback control law
        double delta_a = -Ko * p;

        // Calculate the roll rate at the current time step
        double pdot = 0.5 * p + delta_a;

        // Print the result at the current time step
        cout << "Time: " << t << " seconds, Roll Rate: " << p << " rad/s" << endl;

        // Update the feedback control gain for the next time step
        Ko += alpha * p;

        // Update the roll rate for the next time step
        p += pdot * delta_t;
    }


    // Question 4
    cout << endl << "Question 4" << endl;

    vector<double> w = { 0.0001, 0.0001, 0.0001 };
    vector<double> x = { 124, 31.89, 20.945 };

    double z = dot_product(w, x);
    cout << "Dot Product (z): " << z << endl;


    // Question 5
    cout << endl << "Question 5" << endl;

    double zz = 0.0176835;

    double sig_z = sigmoid(zz);
    double grad_sig_z = gradient_sigmoid(zz);

    cout << "Sigmoid(z): " << sig_z << endl;
    cout << "Gradient of Sigmoid(z): " << grad_sig_z << endl;


    // Question 6
    cout << endl << "Question 6" << endl;

    double y_ = 1.0;
    double y_predicted = 0.504421;

    double grad_cost = gradient_cost(y_predicted, y_);

    cout << "Gradient of Cost: " << grad_cost << endl;


    // Question 7
    cout << endl << "Question 7" << endl;

    double y = 1.0; // Hint

    // Compute gradient weights
    vector<double> dw = gradient_weights(w, x, y);

    // Update weights
    update_weights(w, dw, alpha);

    // Output of updated weights
    cout << "Updated Weights: [";
    for (size_t i = 0; i < w.size(); ++i) {
        cout << w[i];
        if (i < w.size() - 1) {
            cout << ", ";
        }
    }
    cout << "]" << endl;


        // Question 8
        cout << endl << "Question 8" << endl;

        // Aircraft data: [Approach Speed, Wingspan, MTOW, Engine Type]
        vector<vector<double>> training_data = {
            {124.0, 31.89, 20.945, 1.0},
            {74.0, 51.08, 9.170, 0.0},
            {103.0, 34.67, 8.300, 1.0},
            {77.0, 52.00, 9.400, 0.0},
            {104.0, 35.63, 13.000, 1.0},
            {92.0, 56.00, 12.500, 0.0},
            {130.0, 31.29, 17.637, 1.0},
            {73.0, 52.00, 9.600, 0.0}
        };

        // Initialize weights and parameters
        vector<double> www = { 0.0001, 0.0001, 0.0001 };
        double alphaw = 0.001;
        int max_iterations = 100;

        // Train the classifier
        train_classifier(training_data, www, alphaw, max_iterations);

        // Output of updated weights
        cout << "Updated Weights: [";
        for (size_t i = 0; i < www.size(); ++i) {
            cout << www[i];
            if (i < www.size() - 1) {
                cout << ", ";
            }
        }
        cout << "]" << endl;

        // Question 9
        cout << endl << "Question 9" << endl;

        // Aircraft data for prediction
        vector<vector<double>> prediction_data = {
            // [Approach Speed (ft/s), Wingspan (ft), MTOW (kilopound)]
            { 87, 38.67, 6.000 },
            { 79, 52.08, 8.000 },
            { 92, 33.75, 7.804 },
            { 91, 59.25, 16.000 }
        };

        cout << "Predicted Engine Types:" << endl;
        for (const vector<double>& data : prediction_data) {
            // Compute the predicted engine type
            vector<double> x = { data[0], data[1], data[2] };
            double predicted_probability = sigmoid(dot_product(www, x));
            string engine_type = (predicted_probability > 0.5) ? "Jet" : "Turbopoop";  // poop

            // Print the prediction result
            cout << "Approach Speed: " << data[0] << " ft/s, Wingspan: " << data[1] << " ft, MTOW: " << data[2] << " kilopounds - Engine Type: " << engine_type << endl;
        }

        return 0;
    }

